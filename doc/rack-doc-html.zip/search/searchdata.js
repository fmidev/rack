var indexSectionsWithContent =
{
  0: "_abcdefghijklmnopqrstuvwxyz~",
  1: "abcdefghijlmnopqrstuvwz",
  2: "dhr",
  3: "c",
  4: "_abcdefghijlmnopqrstuwz~",
  5: "abcdefghijklmnopqrstuwxy",
  6: "cdgmprsv",
  7: "acdfimqrtw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Pages"
};

