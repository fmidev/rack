var searchData=
[
  ['doppler_20data',['Doppler data',['../dopplerpage.html',1,'']]]
];
