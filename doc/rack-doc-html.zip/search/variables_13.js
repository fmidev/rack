var searchData=
[
  ['undetectqualitycoeff',['undetectQualityCoeff',['../classrack_1_1DataCoder.html#a09c288d10631871e7ed6bfa976e28858',1,'rack::DataCoder']]],
  ['undetectvalue',['undetectValue',['../classrack_1_1DataCoder.html#a8337ce8504bfd5d505a74c80077cfb22',1,'rack::DataCoder::undetectValue()'],['../classrack_1_1Quantity.html#a8337ce8504bfd5d505a74c80077cfb22',1,'rack::Quantity::undetectValue()']]],
  ['unitspeedcoeff',['unitSpeedCoeff',['../classrack_1_1DopplerWindow.html#a2055eef5a4a04c4cb264b68864c08342',1,'rack::DopplerWindow']]],
  ['universal',['UNIVERSAL',['../classrack_1_1DetectorOp.html#ac7d73861600b8d982afcbab299b339fa',1,'rack::DetectorOp']]]
];
