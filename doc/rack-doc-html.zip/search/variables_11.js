var searchData=
[
  ['radialspeedconv',['radialSpeedConv',['../classrack_1_1DopplerWindow.html#a172f6a4ca154432c8597a558a5388e84',1,'rack::DopplerWindow']]],
  ['radialspeedconvinv',['radialSpeedConvInv',['../classrack_1_1DopplerWindow.html#aa3aaa1e28fe7de652873ae58bab9f76e',1,'rack::DopplerWindow']]],
  ['range1',['range1',['../classrack_1_1PolarSector.html#a81f5849bbd8b7b8411bb8898fde4190f',1,'rack::PolarSector']]],
  ['range2',['range2',['../classrack_1_1PolarSector.html#a6efc355e5858258a67b4e8c3e499641f',1,'rack::PolarSector']]],
  ['rangenorm',['rangeNorm',['../classrack_1_1GaussianStripeVertPolarWeighted.html#a6795fb17795f6610ad269cc82f03d14d',1,'rack::GaussianStripeVertPolarWeighted']]],
  ['ray1',['ray1',['../classrack_1_1PolarSector.html#afdc3ee100bd1bfb8a978fb1cd543b766',1,'rack::PolarSector']]],
  ['ray2',['ray2',['../classrack_1_1PolarSector.html#a3b8dbd66bb3ed748383acb1b52fa03cb',1,'rack::PolarSector']]],
  ['refldev',['reflDev',['../classrack_1_1BiometOp.html#ab4db37960c0b65e740729484ef0e949e',1,'rack::BiometOp']]],
  ['reflmax',['reflMax',['../classrack_1_1BiometOp.html#a1b277fdc7d80f38c0cc13ca7ff0dcf30',1,'rack::BiometOp']]],
  ['relativescale',['relativeScale',['../classrack_1_1RadarWindowConfig.html#acb6f121b04ea853b6166c2aecf14e143',1,'rack::RadarWindowConfig']]],
  ['require_5fstandard_5fdata',['REQUIRE_STANDARD_DATA',['../classrack_1_1DetectorOp.html#a788a9f0fa011968823f828262808b703',1,'rack::DetectorOp']]],
  ['root',['ROOT',['../classrack_1_1BaseODIM.html#a04e5048c3a0d78ae8dfd92acd881598b',1,'rack::BaseODIM']]],
  ['rscale',['rscale',['../classrack_1_1PolarODIM.html#ade771d3f57e5219cc8cce838cbc8c62a',1,'rack::PolarODIM']]],
  ['rstart',['rstart',['../classrack_1_1PolarODIM.html#af807d1a13a5ed0ed49cc508a3a77d5f3',1,'rack::PolarODIM']]]
];
