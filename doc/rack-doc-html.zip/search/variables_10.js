var searchData=
[
  ['rad2deg',['RAD2DEG',['../namespacerack.html#abe7ca034063f622e7537cc26baf8e440',1,'rack']]],
  ['range1',['range1',['../classrack_1_1PolarSector.html#a81f5849bbd8b7b8411bb8898fde4190f',1,'rack::PolarSector']]],
  ['range2',['range2',['../classrack_1_1PolarSector.html#a6efc355e5858258a67b4e8c3e499641f',1,'rack::PolarSector']]],
  ['rangenorm',['rangeNorm',['../classrack_1_1GaussianStripeVertPolarWeighted.html#a6795fb17795f6610ad269cc82f03d14d',1,'rack::GaussianStripeVertPolarWeighted']]],
  ['ray1',['ray1',['../classrack_1_1PolarSector.html#afdc3ee100bd1bfb8a978fb1cd543b766',1,'rack::PolarSector']]],
  ['ray2',['ray2',['../classrack_1_1PolarSector.html#a3b8dbd66bb3ed748383acb1b52fa03cb',1,'rack::PolarSector']]],
  ['refldev',['reflDev',['../classrack_1_1BiometOp.html#ab4db37960c0b65e740729484ef0e949e',1,'rack::BiometOp']]],
  ['reflmax',['reflMax',['../classrack_1_1BiometOp.html#a1b277fdc7d80f38c0cc13ca7ff0dcf30',1,'rack::BiometOp']]],
  ['require_5fstandard_5fdata',['REQUIRE_STANDARD_DATA',['../classrack_1_1DetectorOp.html#a788a9f0fa011968823f828262808b703',1,'rack::DetectorOp']]],
  ['rstart',['rstart',['../classrack_1_1PolarODIM.html#af807d1a13a5ed0ed49cc508a3a77d5f3',1,'rack::PolarODIM']]]
];
