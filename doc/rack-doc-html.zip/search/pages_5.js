var searchData=
[
  ['quick_20reference',['Quick reference',['../quickpage.html',1,'']]]
];
