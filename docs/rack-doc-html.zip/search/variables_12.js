var searchData=
[
  ['samplefileextension',['sampleFileExtension',['../namespacerack.html#a90ec0ae5bdd899df6f4ad0e9882e2f66',1,'rack']]],
  ['sensitivity',['sensitivity',['../classrack_1_1SunOp.html#a3db15570a79682b98819ebfded08596b',1,'rack::SunOp']]],
  ['store',['STORE',['../classrack_1_1DetectorOp.html#a68f51e655e1cc819f671c2ee581fc003',1,'rack::DetectorOp']]]
];
