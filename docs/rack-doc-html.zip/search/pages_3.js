var searchData=
[
  ['implementation_20details',['Implementation details',['../detailspage.html',1,'']]],
  ['installation',['Installation',['../installpage.html',1,'']]]
];
